package com.example.bpofficesmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BpOfficesMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BpOfficesMicroserviceApplication.class, args);
	}

}
