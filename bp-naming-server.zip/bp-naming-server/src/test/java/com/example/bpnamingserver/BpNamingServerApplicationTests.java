package com.example.bpnamingserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpNamingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
