package com.example.bpregionsmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpRegionsMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
