package com.example.bpapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
