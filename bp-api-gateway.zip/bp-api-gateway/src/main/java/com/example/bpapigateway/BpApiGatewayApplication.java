package com.example.bpapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BpApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BpApiGatewayApplication.class, args);
	}

}
