package com.example.bpconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
