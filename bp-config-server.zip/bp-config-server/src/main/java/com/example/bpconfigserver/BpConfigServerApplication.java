package com.example.bpconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BpConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BpConfigServerApplication.class, args);
	}

}
