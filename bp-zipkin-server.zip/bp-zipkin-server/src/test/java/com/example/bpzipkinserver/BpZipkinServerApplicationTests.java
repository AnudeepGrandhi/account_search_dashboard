package com.example.bpzipkinserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpZipkinServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
