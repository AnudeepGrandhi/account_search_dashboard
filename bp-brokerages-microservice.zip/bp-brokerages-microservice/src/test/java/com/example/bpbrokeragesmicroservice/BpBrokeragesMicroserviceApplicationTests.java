package com.example.bpbrokeragesmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BpBrokeragesMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
